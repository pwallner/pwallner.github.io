from Components.Converter.Converter import Converter
from Components.Element import cached
from Tools.LoadPixmap import LoadPixmap
from Poll import Poll
from time import time
import json
import urllib2
import os


CHECKIP = "http://ip-api.com/json"
IPDATA = "/tmp/ipdata"
SKINDIR = "/usr/share/enigma2/MetrixStyleHD"
DEFAULTFLAG = "%s/flag/default.png" % SKINDIR
UPDATEPAUSE = 5

TUN = "tun"
IPTABLES = True


def del_ipfiles():
    if os.path.isfile(IPDATA):
        os.remove(IPDATA)


def get_ipdata():
    is_vpn = True if TUN in str(os.listdir("/sys/devices/virtual/net")) else False
    try:
        if is_vpn or not IPTABLES:
            if not os.path.exists(IPDATA) or time() - os.path.getmtime(r"%s" % IPDATA) > UPDATEPAUSE:
                data = urllib2.urlopen(CHECKIP, timeout=4).read()
                f = open(IPDATA, "w")
                f.write(data)
                f.close()
                data = json.loads(data)
            else:
                data = json.loads(open(IPDATA, "r").read())
            country = data["country"].encode("utf-8") if isinstance(data["country"], unicode) else data["country"]
            city = data["city"].encode("utf-8") if isinstance(data["city"], unicode) else data["city"]
            ip = data["query"].encode("utf-8") if isinstance(data["query"], unicode) else data["query"]
        else:
            country = city = ip = None
    except:
        country = city = ip = None
    return country, city, ip, is_vpn


del_ipfiles()


class MetrixStyleVpnInfo(Poll, Converter, object):
    def __init__(self, type):
        Converter.__init__(self, type)
        self.type = type
        Poll.__init__(self)
        self.poll_interval = 60000
        self.poll_enabled = True

    @cached
    def getBoolean(self):
        is_vpn = False
        if self.type == "VPN":
            country, city, ip, is_vpn = get_ipdata()
        if is_vpn:
            return True
        return False

    @cached
    def getText(self):
        text = ""
        country, city, ip, is_vpn = get_ipdata()
        if self.type == "IP":
            if is_vpn or not IPTABLES:
                if ip:
                    text = ip
        elif self.type == "COUNTRYINFO":
            if country and city:
                text = "%s - %s" % (country, city)
        elif self.type == "VPN":
            if country and city and ip:
                text = "%s - %s - %s" % (country, city, ip)
        return text

    @cached
    def getPixmap(self):
        if self.type == 'FLAG':
            country, city, ip, is_vpn = get_ipdata()
            if country:
                flag = "%s/flag/%s.png" % (SKINDIR, country)
                if os.path.exists(flag):
                    png = LoadPixmap(flag)
                else:
                    png = LoadPixmap(DEFAULTFLAG)
            else:
                png = LoadPixmap(DEFAULTFLAG)
            return png
        return None

    pixmap = property(getPixmap)
    boolean = property(getBoolean)
    text = property(getText)
