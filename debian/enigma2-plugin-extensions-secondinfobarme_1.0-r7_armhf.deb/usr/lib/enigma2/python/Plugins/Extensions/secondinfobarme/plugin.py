#######################################################################
#
#    Second InfoBar for Enigma-2
#    Vesion 2.7
#    Coded by Vali (c)2010
#    Support: www.dreambox-tools.info
#
#    This program is free software; you can redistribute it and/or
#    modify it under the terms of the GNU General Public License
#    as published by the Free Software Foundation; either version 2
#    of the License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#######################################################################




from Screens.Screen import Screen
from Screens.InfoBarGenerics import InfoBarPlugins
from Screens.InfoBar import InfoBar
from Screens.MessageBox import MessageBox
from Screens.EpgSelection import EPGSelection
from Screens.Standby import TryQuitMainloop
from Plugins.Plugin import PluginDescriptor
from Components.ActionMap import ActionMap
from Tools.Directories import fileExists
HbbTVInstalled = False
if fileExists("/usr/lib/enigma2/python/Components/Sources/HbbtvApplication.pyo"):
	HbbTVInstalled = True
	from Components.Sources.HbbtvApplication import HbbtvApplication
from Components.config import config, getConfigListEntry, ConfigSubsection, ConfigInteger, ConfigYesNo, ConfigSelection
from Components.ConfigList import ConfigListScreen
from enigma import eTimer, ePoint

# for localized messages
from . import _

MerlinEPGAvailable = False
if fileExists("/usr/lib/enigma2/python/Plugins/Extensions/MerlinEPG/plugin.pyo"):
	from Plugins.Extensions.MerlinEPG.plugin import Merlin_PGII
	MerlinEPGAvailable = True
	
MerlinEPGCenterAvailable = False
if fileExists("/usr/lib/enigma2/python/Plugins/Extensions/MerlinEPGCenter/plugin.pyo"):
	from Plugins.Extensions.MerlinEPGCenter.plugin import MerlinEPGCenterStarter
	MerlinEPGCenterAvailable = True

SIBbase__init__ = None
StartSIBOnceOnly = False
VZ_MODE = "-1"

modechoices = [
				("nothing", _("Disabled")),
				("sib", _("Show SecondInfoBar")),
				("onlysib", _("Show ONLY SecondInfoBar")),
				("subsrv", _("Show Subservices")),
				("epglist", _("Show standard EPG"))
			]


if MerlinEPGAvailable:
	modechoices.append(("merlinepg", _("Show MerlinEPG")))
if MerlinEPGCenterAvailable:
	modechoices.append(("merlinepgcenter", _("Show MerlinEPGCenter")))

config.plugins.SecondInfoBar  = ConfigSubsection()
config.plugins.SecondInfoBar.TimeOut = ConfigInteger(default = 6, limits = (0, 30))
config.plugins.SecondInfoBar.Mode = ConfigSelection(default="sib", choices = modechoices)
config.plugins.SecondInfoBar.HideNormalIB = ConfigYesNo(default = False)
config.plugins.SecondInfoBar.HideSIBonOK = ConfigYesNo(default = False)

def Plugins(**kwargs):
	return [PluginDescriptor(name="SecondInfoBar", where=PluginDescriptor.WHERE_MENU, fnc=SIBsetup),
			PluginDescriptor(where = PluginDescriptor.WHERE_SESSIONSTART, fnc = SIBautostart)]

def SIBsetup(menuid):
	if menuid != "system":
		return [ ]
	return [(_("Second InfoBar Setup"), openSIBsetup, "sibsetup", None)]
	
def openSIBsetup(session, **kwargs):
	session.open(SIBsetupScreen)

class SIBsetupScreen(ConfigListScreen, Screen):
	skin = """
		<screen name="SIBsetupScreen" position="center,center" size="600,340" title="Second-InfoBar setup">
			<eLabel font="Regular;20" foregroundColor="#00ff4A3C" halign="center" position="20,308" size="120,26" text="Cancel"/>
			<eLabel font="Regular;20" foregroundColor="#0056C856" halign="center" position="165,308" size="120,26" text="Save"/>
			<eLabel font="Regular;16" halign="right" valign="center" position="300,308" size="260,26" text="coded: 2010 by Vali / new version by dre"/>
			<widget name="config" position="5,5" scrollbarMode="showOnDemand" size="590,300"/>
		</screen>"""
	def __init__(self, session):
		Screen.__init__(self, session)
		self.session = session
		self.MustRestart = (config.plugins.SecondInfoBar.Mode.value == "onlysib")
		self.list = []

		ConfigListScreen.__init__(self, self.list)
		self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], 
									{
									"red": self.exit, 
									"green": self.save,
									"cancel": self.exit
									}, -1)
									
		config.plugins.SecondInfoBar.Mode.addNotifier(self.buildConfigEntries)
		
	def buildConfigEntries(self, ConfigElement=""):
		self.list = []
		self.list.append(getConfigListEntry(_("SecondInfoBar mode"), config.plugins.SecondInfoBar.Mode))
		self.list.append(getConfigListEntry(_("SecondInfoBar timeout (in sec., 0 = wait for OK)"), config.plugins.SecondInfoBar.TimeOut))
		if config.plugins.SecondInfoBar.Mode.value == "sib":
			self.list.append(getConfigListEntry(_("Hide Infobar when SecondInfoBar is shown"), config.plugins.SecondInfoBar.HideNormalIB))
			self.list.append(getConfigListEntry(_("Close only SecondInfoBar on OK"), config.plugins.SecondInfoBar.HideSIBonOK))
			
		self["config"].list = self.list
		self["config"].l.setList(self.list)		

	def exit(self, ret=""):
		for x in self["config"].list:
			x[1].cancel()
		self.close()

	def save(self):
		for x in self["config"].list:
			x[1].save()
		if (self.MustRestart ^ (config.plugins.SecondInfoBar.Mode.value == "onlysib")):
			self.session.openWithCallback(self.restartConfirmed, MessageBox, _("GUI needs a restart to apply the new settings. Do you want to restart now?"), MessageBox.TYPE_YESNO)
		else:
			self.session.openWithCallback(self.exit, MessageBox, _("Settings saved"), MessageBox.TYPE_INFO)

	def restartConfirmed(self, answer):
		if answer is True:
			self.session.open(TryQuitMainloop, 3)
		else:
			self.close() 

def SIBautostart(reason, **kwargs):
	global SIBbase__init__
	if "session" in kwargs:
		if SIBbase__init__ is None:
			SIBbase__init__ = InfoBarPlugins.__init__
		InfoBarPlugins.__init__ = InfoBarPlugins__init__
		InfoBarPlugins.handleDialogs = handleDialogs
		InfoBarPlugins.hideSIBDialog = hideSIBDialog

def InfoBarPlugins__init__(self):
	global StartSIBOnceOnly
	global VZ_MODE
	if not StartSIBOnceOnly: 
		StartSIBOnceOnly = True
		if fileExists("/usr/lib/enigma2/python/Plugins/Extensions/VirtualZap/plugin.pyo"):
			try:
				VZ_MODE = config.plugins.virtualzap.mode.value
			except:
				VZ_MODE = "-1"
		else:
			VZ_MODE = "-1"
		if VZ_MODE == "1":
			self["SIBActions"] = ActionMap(["SIBwithVZActions"],{"ok_but": self.handleDialogs,"exit_but": self.hideSIBDialog}, -1)
		else:
			self["SIBActions"] = ActionMap(["SIBActions"],{"ok_but": self.handleDialogs,"exit_but": self.hideSIBDialog}, -1)
		self.SIBtimer = eTimer()
		self.SIBtimer_Connection = self.SIBtimer.timeout.connect(self.hideSIBDialog)
		self.SIBdialog = self.session.instantiateDialog(SecondInfoBar, zPosition=1000)
		self.SIBdialog.shown = False

		def CheckSIBtimer():
			if self.SIBtimer.isActive():
				self.SIBtimer.stop()
		self.SIBdialog.onHide.append(CheckSIBtimer)
	else:
		InfoBarPlugins.__init__ = InfoBarPlugins.__init__
		InfoBarPlugins.handleDialogs = None
		InfoBarPlugins.hideSIBDialog = None
	SIBbase__init__(self)

def handleDialogs(self):
	if isinstance(self,InfoBar):
		# show sib with infobar		
		if config.plugins.SecondInfoBar.Mode.value == "sib":
			# only show infobar when OK is pressed for the first time
			if not self.shown and not self.SIBdialog.shown:
				self.toggleShow()
			# show sib when OK is pressed for the second time
			elif self.shown and not self.SIBdialog.shown:
				# close infobar when sib is opened (same mode like onlysib)
				if config.plugins.SecondInfoBar.HideNormalIB.value:
					self.hide()
				self.SIBdialog.show()
			# hide sib when OK is pressed for the third time (infobar timeout was reached already)		
			elif not self.shown and self.SIBdialog.shown:
				self.SIBdialog.hide()
			# hide both when OK is pressed for the third time (before infobar timeout is reached)
			elif self.shown and self.SIBdialog.shown:
				if not config.plugins.SecondInfoBar.HideSIBonOK.value:
					self.hide()
				self.SIBdialog.hide()
			else:
				self.toggleShow()

		# show sib without infobar
		elif config.plugins.SecondInfoBar.Mode.value == "onlysib":
			# show infobar when OK is pressed for the first time
			if not self.shown and not self.SIBdialog.shown:
				self.toggleShow()
			# show only sib when OK is pressed for the second time
			elif self.shown and not self.SIBdialog.shown:
				self.hide()
				self.SIBdialog.show()
			# hide sib when OK is pressed for the third time (before infobar timeout is reached)
			elif not self.shown and self.SIBdialog.shown:
				self.SIBdialog.hide()
			
		elif config.plugins.SecondInfoBar.Mode.value == "epglist":
			if self.shown:
				self.session.open(EPGSelection, self.session.nav.getCurrentlyPlayingServiceReference())
			else:
				self.toggleShow()
		
		elif config.plugins.SecondInfoBar.Mode.value == "merlinepg":
			if self.shown:
				self.session.open(Merlin_PGII, self.servicelist)
			else:
				self.toggleShow()
				
		elif config.plugins.SecondInfoBar.Mode.value == "merlinepgcenter":
			if self.shown:
				MerlinEPGCenterStarter.instance.openMerlinEPGCenter()
			else:
				self.toggleShow()
				
		elif config.plugins.SecondInfoBar.Mode.value == "subsrv":
			if self.shown:
				service = self.session.nav.getCurrentService()
				subservices = service and service.subServices()
				if subservices.getNumberOfSubservices()>0:
					self.subserviceSelection()
				else:
					self.toggleShow()
			else:
				self.toggleShow()
		else:
			self.toggleShow()
			
		if self.SIBdialog.shown:
			sibtimeout = config.plugins.SecondInfoBar.TimeOut.value
			if (sibtimeout > 0):
				self.SIBtimer.start(sibtimeout*1000, True)
			

def hideSIBDialog(self):
	if isinstance(self,InfoBar):	
		if not(self.shown or self.SIBdialog.shown) and (VZ_MODE == "2"):
			self.newHide()
		else:
			self.hide()
			self.SIBdialog.hide()

class SecondInfoBar(Screen):
	skin = """
		<screen name="SecondInfoBar" backgroundColor="#20062748" position="0,0" size="1280,500" title="SecondInfoBar" flags="wfNoBorder">
			<widget source="session.CurrentService" render="Label" position="45,17" size="1185,30" font="Regular; 22" noWrap="1" foregroundColor="#b3b3b9" transparent="0" halign="left" valign="center" backgroundColor="#200d1940">
				<convert type="ServiceName">Name</convert>
			</widget>
			<widget source="session.Event_Now" render="Label" position="210,65" size="415,30" font="Regular; 22" halign="left" backgroundColor="#200d1940" foregroundColor="#b3b3b9" transparent="0" zPosition="5">
				<convert type="EventName">Name</convert>
			</widget>
			<widget source="session.Event_Next" render="Label" position="815,65" size="415,30" font="Regular; 22" halign="left" backgroundColor="#200d1940" foregroundColor="#b3b3b9" transparent="0" zPosition="1">
				<convert type="EventName">Name</convert>
			</widget>
			<widget source="session.Event_Now" render="Label" position="45,65" size="75,30" foregroundColor="#b3b3b9" font="Regular; 22" halign="right" transparent="0" backgroundColor="#200d1940">
				<convert type="EventTime">StartTime</convert>
				<convert type="ClockToText">Default</convert>
			</widget>
			<eLabel text="-" position="120,65" size="15,30" font="Regular; 22" halign="center" foregroundColor="#b3b3b9" transparent="0" backgroundColor="#200d1940" />
			<widget source="session.Event_Now" render="Label" position="135,65" size="75,30" font="Regular; 22" foregroundColor="#b3b3b9" halign="left" transparent="0" backgroundColor="#200d1940">
				<convert type="EventTime">EndTime</convert>
				<convert type="ClockToText">Default</convert>
			</widget>
			<widget source="session.Event_Next" render="Label" position="650,65" size="75,30" font="Regular; 22" halign="right" transparent="0" backgroundColor="#200d1940" foregroundColor="#b3b3b9">
				<convert type="EventTime">StartTime</convert>
				<convert type="ClockToText">Default</convert>
			</widget>
			<eLabel text="-" position="725,65" size="15,30" font="Regular; 22" halign="center" transparent="0" backgroundColor="#200d1940" foregroundColor="#b3b3b9" />
			<widget source="session.Event_Next" render="Label" position="740,65" size="75,30" font="Regular; 22" halign="left" transparent="0" backgroundColor="#200d1940" foregroundColor="#b3b3b9">
				<convert type="EventTime">EndTime</convert>
				<convert type="ClockToText">Default</convert>
			</widget>
			<widget source="session.Event_Now" render="Label" position="45,100" size="580,375" font="Regular; 22" backgroundColor="#200d1940" transparent="0" zPosition="1" foregroundColor="#ffffff">
				<convert type="EventName">ExtendedDescription</convert>
			</widget>
			<widget source="session.Event_Next" render="Label" position="650,100" size="580,375" font="Regular; 22" backgroundColor="#200d1940" transparent="0" zPosition="1" foregroundColor="#ffffff">
				<convert type="EventName">ExtendedDescription</convert>
			</widget>
		</screen>	
	"""
	def __init__(self, session):
		Screen.__init__(self, session)
		self.session = session
		self.skin = SecondInfoBar.skin
		if HbbTVInstalled:
			self["HbbtvApplication"] = HbbtvApplication()
